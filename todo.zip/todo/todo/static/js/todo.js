function changeColor(clickedDiv) {
    clickedDiv.style.backgroundColor = 'green'; // Change the color of the clicked div to red
  }